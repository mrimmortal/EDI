CREATE TABLE `tb_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1

insert into `tb_import` (`id`, `name`, `phone`, `address`) values('1','MAE PONG','1232144','LAMPULO');
insert into `tb_import` (`id`, `name`, `phone`, `address`) values('2','MAE PONG','1232145','LAMPULO');
insert into `tb_import` (`id`, `name`, `phone`, `address`) values('3','MAE PONG','1232146','LAMPULO');
insert into `tb_import` (`id`, `name`, `phone`, `address`) values('4','MAE PONG','1232147','LAMPULO');
insert into `tb_import` (`id`, `name`, `phone`, `address`) values('5','MAE PONG','1232148','LAMPULO');
insert into `tb_import` (`id`, `name`, `phone`, `address`) values('6','MAE PONG','1232149','LAMPULO');
insert into `tb_import` (`id`, `name`, `phone`, `address`) values('7','MAE PONG','1232150','LAMPULO');
insert into `tb_import` (`id`, `name`, `phone`, `address`) values('8','MAE PONG','1232151','LAMPULO');
insert into `tb_import` (`id`, `name`, `phone`, `address`) values('9','MAE PONG','1232152','LAMPULO');
insert into `tb_import` (`id`, `name`, `phone`, `address`) values('10','MAE PONG','1232153','LAMPULO');
insert into `tb_import` (`id`, `name`, `phone`, `address`) values('11','MAE PONG','1232154','LAMPULO');
insert into `tb_import` (`id`, `name`, `phone`, `address`) values('12','MAE PONG','1232155','LAMPULO');
